import { test, expect } from '@playwright/test';

test('TC-001: User Login Success', async ({ page }) => {
  await page.goto('/login');
  await page.fill('input[name="username"]', 'validUsername');
  await page.fill('input[name="password"]', 'validPassword');
  await page.click('button[type="submit"]');
  await expect(page).toHaveURL('/dashboard');
  await expect(page.locator('h1')).toHaveText('Welcome, validUsername');
});