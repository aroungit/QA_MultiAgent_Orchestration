import { test, expect } from '@playwright/test';

test('TC-002: Navigate to Create Lead', async ({ page }) => {
  await page.goto('https://leaftaps.com/opentaps/control/main');
  await page.fill('input[name="username"]', 'Democsr2');
  await page.fill('input[name="password"]', 'crmsfa');
  await page.click('button[type="submit"]');
  await page.click('text=Leads');
  await page.click('text=Create Lead');
  await expect(page).toHaveURL('/leads/create');
});