import { test, expect } from '@playwright/test';

test.describe('Create Lead page input fields', () => {
  test.beforeEach(async ({ page }) => {
    // Navigate to Create Lead page
    await page.goto('https://example.com/create-lead');
  });

  test('TC-003: Enter lead first name', async ({ page }) => {
    const firstNameInput = page.locator('input[name="firstName"]');
    await expect(firstNameInput).toBeVisible();
    await firstNameInput.fill('John');
    await expect(firstNameInput).toHaveValue('John');
  });

  test('TC-004: Enter lead last name', async ({ page }) => {
    const lastNameInput = page.locator('input[name="lastName"]');
    await expect(lastNameInput).toBeVisible();
    await lastNameInput.fill('Doe');
    await expect(lastNameInput).toHaveValue('Doe');
  });
});