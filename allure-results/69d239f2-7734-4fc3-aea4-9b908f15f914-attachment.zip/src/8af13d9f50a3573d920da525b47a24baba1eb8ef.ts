import { test, expect } from '@playwright/test';

test.describe('Create Lead Page', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/create-lead');
  });

  test('TC-003: Enter First Name', async ({ page }) => {
    const firstNameInput = page.locator('#first-name');
    await firstNameInput.fill('John');
    await expect(firstNameInput).toHaveValue('John');
  });

  test('TC-004: Enter Last Name', async ({ page }) => {
    const lastNameInput = page.locator('#last-name');
    await lastNameInput.fill('Doe');
    await expect(lastNameInput).toHaveValue('Doe');
  });
});