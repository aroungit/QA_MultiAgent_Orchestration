import { test, expect } from '@playwright/test';

test.describe('Login Page', () => {
  test('TC-003: Login Button Click', async ({ page }) => {
    await page.goto('https://leaftaps.com/opentaps/control/main');
    const loginButton = page.locator('button[type="submit"]');
    await expect(loginButton).toBeVisible();
    await loginButton.click();
    // TODO: Add assertion to verify the response after clicking the button.
  });

  test('TC-004: Successful Login', async ({ page }) => {
    await page.goto('https://leaftaps.com/opentaps/control/main');
    await page.fill('input[name="username"]', 'Democsr2');
    await page.fill('input[name="password"]', 'crmsfa');
    await page.click('button[type="submit"]');
    // TODO: Add assertion to verify successful login.
  });
});