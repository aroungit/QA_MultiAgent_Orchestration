import { test, expect } from '@playwright/test';

test.describe('Transfer confirmation and audit', () => {
  test.beforeEach(async ({ page }) => {
    // Assume prior steps completed and we are on review screen
    await page.goto('/transfer/review');
  });

  test('TC-011: Require re‑authentication before confirming transfer', async ({ page }) => {
    await page.click('button:has-text("Confirm Transfer")');
    // OTP modal appears
    await page.fill('#otp', '123456'); // placeholder OTP
    await page.click('button:has-text("Submit OTP")');
    // Expect processing screen
    await expect(page).toHaveURL(/.*\/transfer\/processing/);
    const success = page.locator('.success-message');
    await expect(success).toBeVisible();
  });

  test('TC-012: Generate a unique transaction reference ID on successful transfer', async ({ page }) => {
    // Perform a successful transfer (reuse steps from TC-011)
    await page.click('button:has-text("Confirm Transfer")');
    await page.fill('#otp', '123456');
    await page.click('button:has-text("Submit OTP")');
    await expect(page).toHaveURL(/.*\/transfer\/confirmation/);
    const ref1 = page.locator('.transaction-reference');
    await expect(ref1).toBeVisible();
    const refText1 = await ref1.textContent();
    expect(refText1).toMatch(/^[A-Za-z0-9]{12}$/);

    // Initiate a second transfer to verify different reference
    await page.click('button:has-text("New Transfer")');
    await page.fill('input[name="transferAmount"]', '100');
    await page.click('button:has-text("Continue")');
    await page.click('button:has-text("Confirm Transfer")');
    await page.fill('#otp', '123456');
    await page.click('button:has-text("Submit OTP")');
    await expect(page).toHaveURL(/.*\/transfer\/confirmation/);
    const ref2 = page.locator('.transaction-reference');
    await expect(ref2).toBeVisible();
    const refText2 = await ref2.textContent();
    expect(refText2).toMatch(/^[A-Za-z0-9]{12}$/);
    expect(refText2).not.toBe(refText1);
  });
});