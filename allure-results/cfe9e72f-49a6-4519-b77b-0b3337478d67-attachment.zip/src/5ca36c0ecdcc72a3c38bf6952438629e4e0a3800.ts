import { test, expect } from '@playwright/test';

async function loginAndNavigateToTransfer(page) {
  await page.goto('https://example.com/login');
  await page.fill('#username', 'validUser');
  await page.fill('#password', 'validPass');
  await page.click('button[type="submit"]');
  await expect(page).toHaveURL(/\/dashboard/);
  await page.click('nav >> text=Transfer Money');
  await expect(page).toHaveURL(/\/transfer/);
}

test('TC-003: Source account selection is mandatory', async ({ page }) => {
  await loginAndNavigateToTransfer(page);
  // Leave source account unselected
  // Select beneficiary and amount
  await page.selectOption('#beneficiary', 'active-001');
  await page.fill('#amount', '100');
  await page.click('button:has-text("Continue")');
  // Verify validation error
  await expect(page.locator('text=Please select a source account')).toBeVisible();
});

test('TC-004: Inactive beneficiary cannot be used for transfer', async ({ page }) => {
  await loginAndNavigateToTransfer(page);
  await page.selectOption('#sourceAccount', 'savings-123');
  // Choose inactive beneficiary
  await page.selectOption('#beneficiary', 'inactive-999');
  await page.fill('#amount', '50');
  await page.click('button:has-text("Continue")');
  await expect(page.locator('text=Selected beneficiary is not active')).toBeVisible();
});

test('TC-005: Transfer amount must be greater than zero', async ({ page }) => {
  await loginAndNavigateToTransfer(page);
  await page.selectOption('#sourceAccount', 'savings-123');
  await page.selectOption('#beneficiary', 'active-001');
  // Amount zero
  await page.fill('#amount', '0');
  await page.click('button:has-text("Continue")');
  await expect(page.locator('text=Amount must be greater than zero')).toBeVisible();
  // Amount negative
  await page.fill('#amount', '-10');
  await page.click('button:has-text("Continue")');
  await expect(page.locator('text=Amount must be greater than zero')).toBeVisible();
});

test('TC-006: Transfer amount cannot exceed source account balance', async ({ page }) => {
  await loginAndNavigateToTransfer(page);
  await page.selectOption('#sourceAccount', 'savings-123'); // balance $500 assumed
  await page.selectOption('#beneficiary', 'active-001');
  await page.fill('#amount', '600');
  await page.click('button:has-text("Continue")');
  await expect(page.locator('text=Insufficient funds')).toBeVisible();
});

test('TC-007: Transfer amount must respect daily transfer limit', async ({ page }) => {
  await loginAndNavigateToTransfer(page);
  await page.selectOption('#sourceAccount', 'savings-123');
  await page.selectOption('#beneficiary', 'active-001');
  // User already transferred $800, limit $1000, trying $250 exceeds remaining $200
  await page.fill('#amount', '250');
  await page.click('button:has-text("Continue")');
  await expect(page.locator('text=Daily transfer limit exceeded')).toBeVisible();
});