import { test, expect } from '@playwright/test';

test('TC-001: User Login Success', async ({ page }) => {
  await page.goto('https://leaftaps.com/opentaps/control/main');
  await page.fill('input[name="username"]', 'Democsr2');
  await page.fill('input[name="password"]', 'crmsfa');
  await page.click('button[type="submit"]');
  await expect(page).toHaveURL('/dashboard');
  await expect(page.locator('h1')).toHaveText('Welcome, Democsr2');
});