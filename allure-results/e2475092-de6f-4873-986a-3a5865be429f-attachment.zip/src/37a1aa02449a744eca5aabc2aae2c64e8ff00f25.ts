import { test, expect } from '@playwright/test';

test.describe('Create Lead Page', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('https://leaftaps.com/opentaps/control/main');
    await page.fill('input[name="username"]', 'Democsr2');
    await page.fill('input[name="password"]', 'crmsfa');
    await page.click('button[type="submit"]');
    await page.click('text=Leads');
    await page.click('text=Create Lead');
  });

  test('TC-003: Enter First Name', async ({ page }) => {
    const firstNameInput = page.locator('#first-name');
    await firstNameInput.fill('John');
    await expect(firstNameInput).toHaveValue('John');
  });

  test('TC-004: Enter Last Name', async ({ page }) => {
    const lastNameInput = page.locator('#last-name');
    await lastNameInput.fill('Doe');
    await expect(lastNameInput).toHaveValue('Doe');
  });
});