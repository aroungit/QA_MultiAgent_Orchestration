import { test, expect } from '@playwright/test';

test.describe('Login Page', () => {
  test('TC-003: Verify Login button visibility and enablement logic', async ({ page }) => {
    await page.goto('/login');
    const username = page.locator('input[name="username"]');
    const password = page.locator('input[name="password"]');
    const loginButton = page.getByRole('button', { name: 'Login' });

    // Verify button is visible and disabled initially
    await expect(loginButton).toBeVisible();
    await expect(loginButton).toBeDisabled();

    // Fill username only
    await username.fill('someUser');
    await expect(loginButton).toBeDisabled();

    // Fill password
    await password.fill('somePass');
    await expect(loginButton).toBeEnabled();
  });

  test('TC-004: Successful authentication with valid credentials', async ({ page }) => {
    await page.goto('/login');
    const username = page.locator('input[name="username"]');
    const password = page.locator('input[name="password"]');
    const loginButton = page.getByRole('button', { name: 'Login' });

    await username.fill('validUser');
    await password.fill('ValidPass123');
    await expect(loginButton).toBeEnabled();
    await loginButton.click();

    // Wait for navigation to dashboard
    await page.waitForURL('**/dashboard**');

    // Verify no error message is displayed
    const errorMessage = page.locator('.error-message');
    await expect(errorMessage).toHaveCount(0);
  });
});