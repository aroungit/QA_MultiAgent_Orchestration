import { test, expect } from '@playwright/test';

test.describe('Transfer Feature', () => {
  test('TC-001: Initiate transfer between own checking and savings accounts', async ({ page }) => {
    await page.goto('/transfer');
    await page.selectOption('#source-account', 'checking');
    await page.selectOption('#destination-account', 'savings');
    await page.fill('#transfer-amount', '100.00');
    await page.fill('#transfer-date', new Date().toISOString().split('T')[0]);
    await page.click('#continue-button');
    const confirmationSummary = await page.locator('#confirmation-summary');
    await expect(confirmationSummary).toBeVisible();
    await expect(page.locator('.error-message')).toHaveCount(0);
  });

  test('TC-002: Validate source account selection is required', async ({ page }) => {
    await page.goto('/transfer');
    await page.selectOption('#destination-account', 'savings');
    await page.fill('#transfer-amount', '50');
    await page.fill('#transfer-date', '2023-12-31');
    await page.click('#continue-button');
    await expect(page.locator('.error-message')).toHaveText('Please select a source account');
    const confirmationSummary = await page.locator('#confirmation-summary');
    await expect(confirmationSummary).toHaveCount(0);
  });
});