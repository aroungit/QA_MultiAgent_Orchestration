import { test, expect } from "@playwright/test";

test('TC-001: Valid user login', async ({ page }) => {
  // Preconditions: application reachable, user exists
  await page.goto('https://example.com/login');
  await expect(page).toHaveURL(/login/);

  // Step: Enter username
  await page.fill('#username', 'valid_user');
  // Step: Enter password
  await page.fill('#password', 'valid_password');
  // Step: Click Login
  await page.click('button:has-text("Login")');

  // Expected: authenticated and redirected to dashboard
  await expect(page).toHaveURL(/dashboard/);
  // Expected: logged‑in user’s name displayed in header
  const userName = page.locator('header .user-name');
  await expect(userName).toBeVisible();
  await expect(userName).toHaveText('valid_user');
});
