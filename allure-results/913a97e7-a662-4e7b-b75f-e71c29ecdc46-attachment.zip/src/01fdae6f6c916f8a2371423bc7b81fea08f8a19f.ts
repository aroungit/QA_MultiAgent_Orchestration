import { test, expect } from '@playwright/test';

test.describe('Transfer amount daily limit validation', () => {
  test.beforeEach(async ({ page }) => {
    // Assume user is already logged in via storage state or login helper
    await page.goto('/transfer');
  });

  test('TC-009: Accept transfer amount within daily limit', async ({ page }) => {
    await page.fill('input[name="transferAmount"]', '3000');
    await page.click('button:has-text("Continue")');
    // Expect navigation to authentication step
    await expect(page).toHaveURL(/.*\/transfer\/authenticate/);
  });

  test('TC-010: Reject transfer amount exceeding daily limit', async ({ page }) => {
    await page.fill('input[name="transferAmount"]', '600');
    await page.click('button:has-text("Continue")');
    const error = page.locator('.error-message');
    await expect(error).toBeVisible();
    await expect(error).toContainText('Transfer amount exceeds daily limit');
    // Ensure still on same page
    await expect(page).toHaveURL(/.*\/transfer/);
  });
});