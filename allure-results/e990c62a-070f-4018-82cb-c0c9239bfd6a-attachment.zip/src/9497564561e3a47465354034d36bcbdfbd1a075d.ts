import { test, expect } from '@playwright/test';

// Helper to perform login
async function login(page) {
  await page.goto('https://example.com/login');
  await page.fill('#username', 'validUser');
  await page.fill('#password', 'validPass');
  await page.click('button[type="submit"]');
  await expect(page).toHaveURL(/\/dashboard/);
}

test('TC-001: Unauthenticated user cannot access money transfer page', async ({ page }) => {
  // Open the application URL
  await page.goto('https://example.com');
  // Directly navigate to the transfer page
  await page.goto('https://example.com/transfer');
  // Expect redirect to login page
  await expect(page).toHaveURL(/\/login/);
  // Verify authentication required message
  await expect(page.locator('text=Authentication required')).toBeVisible();
});

test('TC-002: Authenticated user can access money transfer page', async ({ page }) => {
  await page.goto('https://example.com');
  await login(page);
  // Click the Transfer Money menu item
  await page.click('nav >> text=Transfer Money');
  await expect(page).toHaveURL(/\/transfer/);
  // Verify transfer fields are visible
  await expect(page.locator('#sourceAccount')).toBeVisible();
  await expect(page.locator('#beneficiary')).toBeVisible();
  await expect(page.locator('#amount')).toBeVisible();
});

test('TC-008: User re‑authentication required before confirming transfer', async ({ page }) => {
  await page.goto('https://example.com');
  await login(page);
  // Navigate to transfer page and fill valid details
  await page.click('nav >> text=Transfer Money');
  await page.selectOption('#sourceAccount', 'savings-123');
  await page.selectOption('#beneficiary', 'beneficiary-456');
  await page.fill('#amount', '150');
  await page.click('button:has-text("Continue")');
  // Assume re‑authentication screen appears
  await expect(page).toHaveURL(/\/transfer\/reauth/);
  // Enter incorrect OTP
  await page.fill('#otp', '000000');
  await page.click('button:has-text("Confirm")');
  await expect(page.locator('text=Invalid authentication code')).toBeVisible();
  // Enter correct OTP
  await page.fill('#otp', '123456');
  await page.click('button:has-text("Confirm")');
  // Verify transfer proceeds to confirmation screen
  await expect(page).toHaveURL(/\/transfer\/confirmation/);
});