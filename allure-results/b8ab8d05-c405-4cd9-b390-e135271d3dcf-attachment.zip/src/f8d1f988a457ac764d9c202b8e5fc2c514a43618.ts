import { test, expect } from '@playwright/test';

async function login(page) {
  await page.goto('https://example.com/login');
  await page.fill('#username', 'validUser');
  await page.fill('#password', 'validPass');
  await page.click('button[type="submit"]');
  await expect(page).toHaveURL(/\/dashboard/);
}

async function startTransfer(page, amount) {
  await page.click('nav >> text=Transfer Money');
  await page.selectOption('#sourceAccount', 'savings-123');
  await page.selectOption('#beneficiary', 'active-001');
  await page.fill('#amount', amount.toString());
  await page.click('button:has-text("Continue")');
  // Re‑authentication step
  await expect(page).toHaveURL(/\/transfer\/reauth/);
  await page.fill('#otp', '123456');
  await page.click('button:has-text("Confirm")');
  await expect(page).toHaveURL(/\/transfer\/confirmation/);
}

test('TC-009: Unique transaction reference is generated on successful transfer', async ({ page }) => {
  await login(page);
  // First transfer
  await startTransfer(page, 100);
  const ref1 = await page.textContent('#transactionReference');
  await expect(ref1).toMatch(/[A-Za-z0-9]{8,}/);
  // Return to dashboard to start a second transfer
  await page.click('nav >> text=Dashboard');
  await startTransfer(page, 150);
  const ref2 = await page.textContent('#transactionReference');
  await expect(ref2).toMatch(/[A-Za-z0-9]{8,}/);
  // References should be different
  expect(ref1).not.toBe(ref2);
});

test('TC-010: Balance and transaction history update after successful transfer', async ({ page }) => {
  await login(page);
  // Assume initial balance $1000 displayed on account summary
  await page.click('nav >> text=Account Summary');
  const initialBalanceText = await page.textContent('#balance');
  const initialBalance = parseFloat(initialBalanceText.replace(/[^0-9.-]+/g, ''));
  expect(initialBalance).toBe(1000);
  // Perform transfer of $200
  await startTransfer(page, 200);
  // Verify new balance
  await page.click('nav >> text=Account Summary');
  const newBalanceText = await page.textContent('#balance');
  const newBalance = parseFloat(newBalanceText.replace(/[^0-9.-]+/g, ''));
  expect(newBalance).toBe(800);
  // Verify transaction history entry
  await page.click('nav >> text=Transaction History');
  const latestEntry = page.locator('.transaction-row').first();
  await expect(latestEntry).toContainText('$200');
  await expect(latestEntry).toContainText('active-001');
  const reference = await latestEntry.textContent();
  await expect(reference).toMatch(/[A-Za-z0-9]{8,}/);
});

test('TC-011: No funds are deducted when transfer fails', async ({ page }) => {
  await login(page);
  // Verify starting balance $500
  await page.click('nav >> text=Account Summary');
  const startBalText = await page.textContent('#balance');
  const startBal = parseFloat(startBalText.replace(/[^0-9.-]+/g, ''));
  expect(startBal).toBe(500);
  // Attempt transfer that exceeds daily limit
  await page.click('nav >> text=Transfer Money');
  await page.selectOption('#sourceAccount', 'savings-123');
  await page.selectOption('#beneficiary', 'active-001');
  await page.fill('#amount', '100'); // would exceed remaining $50 of $300 limit
  await page.click('button:has-text("Continue")');
  // Expect daily limit error before re‑auth
  await expect(page.locator('text=Daily transfer limit exceeded')).toBeVisible();
  // Balance should remain unchanged
  await page.click('nav >> text=Account Summary');
  const afterBalText = await page.textContent('#balance');
  const afterBal = parseFloat(afterBalText.replace(/[^0-9.-]+/g, ''));
  expect(afterBal).toBe(500);
  // No new transaction entry
  await page.click('nav >> text=Transaction History');
  const rows = await page.locator('.transaction-row').count();
  // Assuming there were no prior entries for this test, count should be 0
  expect(rows).toBe(0);
});