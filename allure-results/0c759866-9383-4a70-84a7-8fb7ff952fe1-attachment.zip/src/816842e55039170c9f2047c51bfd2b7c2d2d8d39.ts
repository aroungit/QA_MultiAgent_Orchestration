import { test, expect } from '@playwright/test';

test.describe('Lead Management', () => {
  test('TC-007: Lead Creation Success', async ({ page }) => {
    await page.goto('https://leaftaps.com/opentaps/control/main');
    await page.fill('input[name="username"]', 'Democsr2');
    await page.fill('input[name="password"]', 'crmsfa');
    await page.click('button[type="submit"]');
    await page.click('#create-lead');
    await page.waitForSelector('.success-message');
    const successMessage = await page.textContent('.success-message');
    expect(successMessage).toContain('Lead created successfully');
  });

  test('TC-008: Display Lead Information', async ({ page }) => {
    await page.goto('https://leaftaps.com/opentaps/control/main');
    await page.fill('input[name="username"]', 'Democsr2');
    await page.fill('input[name="password"]', 'crmsfa');
    await page.click('button[type="submit"]');
    const leadInfo = await page.textContent('#lead-info');
    expect(leadInfo).toContain('Newly created lead information');
  });
});