import { test, expect } from '@playwright/test';

test.describe('Transfer Amount Validation', () => {
  test.beforeEach(async ({ page }) => {
    // Placeholder for login and navigation to transfer page
    await page.goto('https://example.com/login');
    // Assume login steps
    await page.fill('#username', 'testuser');
    await page.fill('#password', 'password');
    await page.click('button:has-text("Login")');
    // Navigate to transfer page
    await page.goto('https://example.com/transfer');
    // Select source account and beneficiary (placeholders)
    await page.selectOption('#source-account', 'account-1');
    await page.selectOption('#beneficiary', 'beneficiary-1');
  });

  test('TC-005 Accept transfer amount greater than zero', async ({ page }) => {
    await page.fill('#transfer-amount', '100.00');
    await page.click('button:has-text("Continue")');
    // Expect navigation to authentication step
    await expect(page).toHaveURL(/.*\/authentication/);
    // No validation error
    await expect(page.locator('.error-message')).toBeHidden();
  });

  test('TC-006 Reject zero or negative transfer amount', async ({ page }) => {
    // Zero amount
    await page.fill('#transfer-amount', '0');
    await page.click('button:has-text("Continue")');
    await expect(page.locator('.error-message')).toContainText('Amount must be greater than zero');
    await expect(page).toHaveURL(/.*\/transfer/);
    // Negative amount
    await page.fill('#transfer-amount', '-50');
    await page.click('button:has-text("Continue")');
    await expect(page.locator('.error-message')).toContainText('Amount must be greater than zero');
    await expect(page).toHaveURL(/.*\/transfer/);
  });

  test('TC-007 Allow transfer amount within available balance', async ({ page }) => {
    await page.fill('#transfer-amount', '500.00');
    await page.click('button:has-text("Continue")');
    await expect(page).toHaveURL(/.*\/authentication/);
    await expect(page.locator('.error-message')).toBeHidden();
  });

  test('TC-008 Prevent transfer amount exceeding available balance', async ({ page }) => {
    await page.fill('#transfer-amount', '400.00');
    await page.click('button:has-text("Continue")');
    await expect(page.locator('.error-message')).toContainText('Insufficient funds');
    await expect(page).toHaveURL(/.*\/transfer/);
  });
});