import { test, expect } from "@playwright/test";

test('TC-003: Active beneficiary validation before processing transfer', async ({ page }) => {
  // Log in
  await page.goto('https://example.com/login');
  await page.fill('#username', 'testuser');
  await page.fill('#password', 'Password123');
  await page.click('button[type="submit"]');
  // Go to transfer page
  await page.goto('https://example.com/transfer');
  // Start a new transfer
  await page.click('button#new-transfer');
  // Select an inactive beneficiary
  await page.selectOption('#beneficiary', { label: 'Inactive Beneficiary' });
  // Attempt to proceed
  await page.click('button#next-step');
  // Expect error message
  const error = page.locator('.error-message', { hasText: 'Beneficiary is not active' });
  await expect(error).toBeVisible();
  // Select an active beneficiary
  await page.selectOption('#beneficiary', { label: 'Active Beneficiary' });
  // Proceed to next step
  await page.click('button#next-step');
  // Error should disappear and next step should be visible
  await expect(error).toHaveCount(0);
  const nextStep = page.locator('#transfer-details');
  await expect(nextStep).toBeVisible();
});