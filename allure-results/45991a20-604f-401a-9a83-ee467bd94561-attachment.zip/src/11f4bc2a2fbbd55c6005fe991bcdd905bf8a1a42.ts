import { test, expect } from '@playwright/test';

test.describe('Transfer Page', () => {
  test('TC-009: Display confirmation summary with correct details', async ({ page }) => {
    // Preconditions: User is signed in, has checking and savings accounts, and sufficient balance
    await page.goto('/transfer');
    await page.selectOption('#source-account', 'checking');
    await page.selectOption('#destination-account', 'savings');
    await page.fill('#amount', '150.00');
    await page.fill('#transfer-date', new Date().toISOString().split('T')[0]); // today's date
    await page.click('#continue-button');

    // Expected Results
    const confirmationSummary = await page.locator('#confirmation-summary');
    await expect(confirmationSummary).toBeVisible();
    await expect(confirmationSummary.locator('.source-account')).toHaveText('checking');
    await expect(confirmationSummary.locator('.destination-account')).toHaveText('savings');
    await expect(confirmationSummary.locator('.amount')).toHaveText('$150.00');
    await expect(confirmationSummary.locator('.date')).toHaveText(new Date().toLocaleDateString()); // today's date
  });
});