import { test, expect } from '@playwright/test';

test.describe('Authentication Tests', () => {
  test('TC-006: Error Message for Invalid Credentials', async ({ page }) => {
    await page.goto('https://leaftaps.com/opentaps/control/main');
    await page.fill('input[name="username"]', 'invalidUser');
    await page.fill('input[name="password"]', 'wrongPassword');
    await page.click('button[type="submit"]');
    const errorMessage = await page.locator('.error-message'); // Adjust selector based on actual implementation
    await expect(errorMessage).toBeVisible();
  });

  test('TC-005: Display Home Page After Login', async ({ page }) => {
    await page.goto('https://leaftaps.com/opentaps/control/main');
    await page.fill('input[name="username"]', 'Democsr2');
    await page.fill('input[name="password"]', 'crmsfa');
    await page.click('button[type="submit"]');
    await expect(page).toHaveURL(/.*home/); // Adjust based on actual home page URL
    await expect(page.locator('h1')).toHaveText('Welcome to Leaftaps'); // Adjust selector based on actual implementation
  });
});