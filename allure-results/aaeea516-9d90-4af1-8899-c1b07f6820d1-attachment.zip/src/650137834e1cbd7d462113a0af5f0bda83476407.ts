import { test, expect } from "@playwright/test";

test.describe('Money Transfer Flow', () => {
  test.beforeEach(async ({ page }) => {
    // Log in once for all tests
    await page.goto('https://example.com/login');
    await page.fill('input[name="username"]', 'testuser');
    await page.fill('input[name="password"]', 'Password123');
    await page.click('button:has-text("Sign In")');
    await expect(page).toHaveURL(/.*\/dashboard/);
  });

  test('TC-002 Select a source savings account for transfer', async ({ page }) => {
    await page.goto('https://example.com/transfer');
    await page.click('label:has-text("Source Account") + div >> role=button');
    const accountOption = page.locator('[data-test-id="account-12345"]');
    await accountOption.click();
    const sourceField = page.locator('#source-account-field');
    await expect(sourceField).toContainText('12345');
    const balance = page.locator('#source-account-balance');
    await expect(balance).toContainText('$');
  });

  test('TC-003 Allow transfer to an active beneficiary', async ({ page }) => {
    await page.goto('https://example.com/transfer');
    await page.click('label:has-text("Source Account") + div >> role=button');
    await page.locator('[data-test-id="account-12345"]').click();
    await page.fill('input[name="beneficiary"]', 'John Doe');
    const suggestion = page.locator('.autocomplete-item', { hasText: 'John Doe' });
    await suggestion.click();
    const continueBtn = page.locator('button:has-text("Continue")');
    await expect(continueBtn).toBeEnabled();
    const errorMsg = page.locator('.beneficiary-error');
    await expect(errorMsg).toBeHidden();
  });

  test('TC-004 Prevent transfer to an inactive beneficiary', async ({ page }) => {
    await page.goto('https://example.com/transfer');
    await page.click('label:has-text("Source Account") + div >> role=button');
    await page.locator('[data-test-id="account-12345"]').click();
    await page.fill('input[name="beneficiary"]', 'Jane Inactive');
    const suggestion = page.locator('.autocomplete-item', { hasText: 'Jane Inactive' });
    await suggestion.click();
    const continueBtn = page.locator('button:has-text("Continue")');
    await expect(continueBtn).toBeDisabled();
    const errorMsg = page.locator('.beneficiary-error');
    await expect(errorMsg).toHaveText(/Beneficiary is inactive/);
  });
});