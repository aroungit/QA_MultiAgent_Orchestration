import { test, expect } from "@playwright/test";

test('TC-002: Only savings accounts can be selected as source account', async ({ page }) => {
  // Log in
  await page.goto('https://example.com/login');
  await page.fill('#username', 'testuser');
  await page.fill('#password', 'Password123');
  await page.click('button[type="submit"]');
  // Navigate to transfer page
  await page.goto('https://example.com/transfer');
  // Open source account dropdown
  const dropdown = page.locator('#source-account');
  await dropdown.click();
  // Get all options
  const options = page.locator('#source-account option');
  const count = await options.count();
  for (let i = 0; i < count; i++) {
    const option = options.nth(i);
    const type = await option.getAttribute('data-account-type');
    // Expect only savings accounts
    expect(type).toBe('savings');
  }
  // Verify no checking accounts are present
  const checkingOption = options.filter({ hasText: 'Checking' });
  await expect(checkingOption).toHaveCount(0);
});