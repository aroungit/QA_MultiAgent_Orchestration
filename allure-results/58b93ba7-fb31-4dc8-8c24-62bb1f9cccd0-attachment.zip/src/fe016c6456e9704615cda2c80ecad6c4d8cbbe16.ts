import { test, expect } from '@playwright/test';

test.describe('Login Page', () => {
  test('TC-001 - Valid Username Entry', async ({ page }) => {
    await page.goto('https://leaftaps.com/opentaps/control/main');
    const usernameField = page.locator('input[name="username"]');
    await usernameField.fill('Democsr2');
    await expect(usernameField).toHaveValue('Democsr2');
  });

  test('TC-002 - Valid Password Entry', async ({ page }) => {
    await page.goto('https://leaftaps.com/opentaps/control/main');
    const passwordField = page.locator('input[name="password"]');
    await passwordField.fill('crmsfa');
    await expect(passwordField).toHaveValue('crmsfa');
  });
});