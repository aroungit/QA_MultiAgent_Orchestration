import { test, expect } from '@playwright/test';

test('TC-001: Successful login with valid credentials', async ({ page }) => {
  await page.goto('/login');
  await page.fill('#username', 'user');
  await page.fill('#password', 'pass');
  await page.click('#submit');
  await expect(page).toHaveURL('/dashboard');
});
