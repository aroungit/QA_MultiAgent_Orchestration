import { test, expect } from '@playwright/test';

test.describe('Create Lead Page', () => {
  test('TC-005: Enter Company Name', async ({ page }) => {
    await page.goto('/create-lead');
    const companyNameInput = page.locator('#company-name');
    await companyNameInput.fill('Valid Company Name');
    const value = await companyNameInput.inputValue();
    expect(value).toBe('Valid Company Name');
  });

  test('TC-006: Click Create Lead Button', async ({ page }) => {
    await page.goto('/create-lead');
    await page.fill('#company-name', 'Valid Company Name');
    await page.click('#create-lead-button');
    // Add assertion to verify lead creation, e.g., check for a success message
    const successMessage = page.locator('.success-message');
    await expect(successMessage).toBeVisible();
  });
});