import { test, expect } from "@playwright/test";

test('TC-001 Verify authentication is required before initiating a money transfer', async ({ page }) => {
  // Preconditions: user not logged in
  // Navigate to Money Transfer page
  await page.goto('https://example.com/transfer');
  // Expect redirect to login page
  await expect(page).toHaveURL(/.*\/login/);
  // Or login prompt visible
  const loginPrompt = page.locator('text=Please sign in');
  await expect(loginPrompt).toBeVisible();
  // Transfer UI elements should not be visible
  const transferForm = page.locator('#transfer-form');
  await expect(transferForm).toBeHidden();
});