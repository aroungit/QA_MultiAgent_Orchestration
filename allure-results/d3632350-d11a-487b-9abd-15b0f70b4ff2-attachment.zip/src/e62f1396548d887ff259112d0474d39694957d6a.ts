import { test, expect } from '@playwright/test';

test('TC-002: Navigate to Create Lead', async ({ page }) => {
  await page.goto('/dashboard');
  await page.click('text=Leads');
  await page.click('text=Create Lead');
  await expect(page).toHaveURL('/leads/create');
});