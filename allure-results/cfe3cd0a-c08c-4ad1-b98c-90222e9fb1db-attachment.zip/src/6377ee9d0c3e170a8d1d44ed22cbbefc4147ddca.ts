import { test, expect } from '@playwright/test';

test('TC-001: Verify presence and basic functionality of Username input field', async ({ page }) => {
  await page.goto('/login');
  const username = page.getByLabel('Username');
  await expect(username).toBeVisible();
  await expect(username).toBeEnabled();
  await username.click();
  await expect(username).toBeFocused();
  await username.fill('testUser123');
  await expect(username).toHaveValue('testUser123');
});

test('TC-002: Verify presence and masking behavior of Password input field', async ({ page }) => {
  await page.goto('/login');
  const password = page.getByLabel('Password');
  await expect(password).toBeVisible();
  await expect(password).toBeEnabled();
  await password.click();
  await expect(password).toBeFocused();
  await password.fill('Secret!@#');
  await expect(password).toHaveAttribute('type', 'password');
  const value = await password.inputValue();
  expect(value).toBe('Secret!@#');
});