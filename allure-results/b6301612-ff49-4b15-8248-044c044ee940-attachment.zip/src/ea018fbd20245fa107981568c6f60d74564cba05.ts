import { test, expect } from '@playwright/test';

test.describe('Transfer Page Validations', () => {
  test('TC-003: Validate destination account selection is required', async ({ page }) => {
    await page.goto('/transfer');
    await page.selectOption('#sourceAccount', 'sourceAccountId');
    await page.fill('#destinationAccount', '');
    await page.fill('#amount', '50');
    await page.fill('#transferDate', '2023-12-31');
    await page.click('#continueButton');
    const validationMessage = await page.locator('.validation-message').innerText();
    expect(validationMessage).toBe('Please select a destination account');
    await expect(page).not.toHaveURL(/confirmation/);
  });

  test('TC-004: Validate transfer amount entry is required', async ({ page }) => {
    await page.goto('/transfer');
    await page.selectOption('#sourceAccount', 'sourceAccountId');
    await page.selectOption('#destinationAccount', 'destinationAccountId');
    await page.fill('#amount', '');
    await page.fill('#transferDate', '2023-12-31');
    await page.click('#continueButton');
    const validationMessage = await page.locator('.validation-message').innerText();
    expect(validationMessage).toBe('Please enter a transfer amount');
    await expect(page).not.toHaveURL(/confirmation/);
  });
});