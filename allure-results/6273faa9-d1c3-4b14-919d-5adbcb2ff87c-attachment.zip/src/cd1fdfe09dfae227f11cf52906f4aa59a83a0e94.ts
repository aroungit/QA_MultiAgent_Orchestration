import { test, expect } from '@playwright/test';

test.describe('Transfer validations', () => {
  test.beforeEach(async ({ page }) => {
    // Assume user is already logged in; if not, perform login
    await page.goto('https://example.com/dashboard');
    // Optionally verify login state
    await expect(page).toHaveURL(/dashboard/);
  });

  test('TC-005: Insufficient balance prevents transfer', async ({ page }) => {
    // Preconditions: source account balance $100 (assume displayed)
    await page.goto('https://example.com/transfer');
    // Start a new transfer
    await page.click('button:has-text("New Transfer")');
    // Enter amount $150
    await page.fill('#transfer-amount', '150');
    // Submit
    await page.click('button:has-text("Submit")');
    // Expect error message
    const error = page.locator('.notification-error');
    await expect(error).toContainText('Insufficient funds');
    // Verify balance unchanged
    const balance = page.locator('#account-balance');
    await expect(balance).toHaveText('$100');
  });

  test('TC-006: Daily transfer limit enforcement', async ({ page }) => {
    await page.goto('https://example.com/transfer');
    await page.click('button:has-text("New Transfer")');
    await page.fill('#transfer-amount', '150');
    await page.click('button:has-text("Submit")');
    const error = page.locator('.notification-error');
    await expect(error).toContainText('Transfer exceeds daily limit');
    const balance = page.locator('#account-balance');
    await expect(balance).toHaveText('$100');
  });

  test('TC-007: Transaction re‑authentication (OTP) before execution', async ({ page }) => {
    // Complete transfer form
    await page.goto('https://example.com/transfer');
    await page.click('button:has-text("New Transfer")');
    await page.fill('#transfer-amount', '50');
    await page.click('button:has-text("Submit")');
    // System prompts for OTP
    await expect(page.locator('#otp-prompt')).toBeVisible();

    // Correct OTP flow
    await page.fill('#otp-input', '123456');
    await page.click('button:has-text("Confirm")');
    const successMsg = page.locator('.notification-success');
    await expect(successMsg).toContainText('Transfer completed');

    // Restart flow for incorrect OTP
    await page.goto('https://example.com/transfer');
    await page.click('button:has-text("New Transfer")');
    await page.fill('#transfer-amount', '50');
    await page.click('button:has-text("Submit")');
    await expect(page.locator('#otp-prompt')).toBeVisible();
    await page.fill('#otp-input', '000000');
    await page.click('button:has-text("Confirm")');
    const authError = page.locator('.notification-error');
    await expect(authError).toContainText('authentication error');
  });

  test('TC-008: Unique transaction reference generated on successful transfer', async ({ page }) => {
    await page.goto('https://example.com/transfer');
    await page.click('button:has-text("New Transfer")');
    await page.fill('#transfer-amount', '30');
    await page.click('button:has-text("Submit")');
    // Assume OTP not required for this test or already handled
    const reference = page.locator('#transaction-reference');
    await expect(reference).toBeVisible();
    const refText = await reference.textContent();
    expect(refText?.trim().length).toBeGreaterThan(0);
  });
});