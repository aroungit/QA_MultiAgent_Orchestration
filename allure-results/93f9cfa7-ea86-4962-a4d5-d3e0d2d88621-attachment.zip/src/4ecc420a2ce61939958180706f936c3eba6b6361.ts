import { test, expect } from "@playwright/test";

test('TC-001: Authentication required before initiating a money transfer', async ({ page }) => {
  // Attempt to access transfer page without logging in
  await page.goto('https://example.com/transfer');
  // Expect redirect to login page
  await expect(page).toHaveURL(/.*\/login/);
  // Or check for login form
  const loginForm = page.locator('form#loginForm');
  await expect(loginForm).toBeVisible();
  // Ensure transfer UI elements are not present
  const transferHeader = page.locator('h1', { hasText: 'Transfer Money' });
  await expect(transferHeader).toHaveCount(0);
});