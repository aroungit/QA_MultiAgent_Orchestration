import { test, expect } from "@playwright/test";

test('TC-004: Transfer amount must be greater than zero', async ({ page }) => {
  // Log in
  await page.goto('https://example.com/login');
  await page.fill('#username', 'testuser');
  await page.fill('#password', 'Password123');
  await page.click('button[type="submit"]');
  // Navigate to transfer page
  await page.goto('https://example.com/transfer');
  // Initiate a transfer
  await page.click('button#new-transfer');
  // Enter zero amount and submit
  await page.fill('#amount', '0');
  await page.click('#submit-transfer');
  const zeroError = page.locator('.error-message', { hasText: 'Amount must be greater than zero' });
  await expect(zeroError).toBeVisible();
  // Enter negative amount and submit
  await page.fill('#amount', '-50');
  await page.click('#submit-transfer');
  const negativeError = page.locator('.error-message', { hasText: 'Amount must be greater than zero' });
  await expect(negativeError).toBeVisible();
});