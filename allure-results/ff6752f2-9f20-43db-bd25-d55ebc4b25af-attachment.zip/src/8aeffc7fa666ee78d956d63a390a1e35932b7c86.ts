import { test, expect } from "@playwright/test";

test('TC-002: Navigate to Create Lead page', async ({ page }) => {
  // Preconditions: user is logged in and Home screen displayed
  // Perform login steps
  await page.goto('https://example.com/login');
  await page.fill('#username', 'valid_user');
  await page.fill('#password', 'valid_password');
  await page.click('button:has-text("Login")');
  await expect(page).toHaveURL(/dashboard/);

  // Step: Click the "Leads" menu item
  await page.click('nav >> text=Leads');
  // Step: Select the "Create Lead" option
  await page.click('text=Create Lead');

  // Expected: Create Lead page loads
  await expect(page).toHaveURL(/create-lead/);
  // Verify input fields are visible
  await expect(page.locator('#firstName')).toBeVisible();
  await expect(page.locator('#lastName')).toBeVisible();
  await expect(page.locator('#companyName')).toBeVisible();
});
