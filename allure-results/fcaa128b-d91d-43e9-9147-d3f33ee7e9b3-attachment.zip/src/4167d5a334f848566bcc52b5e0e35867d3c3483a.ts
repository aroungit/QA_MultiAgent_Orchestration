import { test, expect } from "@playwright/test";

let leadId: string;

test('TC-007: Verify lead record is created successfully', async ({ page }) => {
  // Navigate to lead creation page
  await page.goto('/leads/create');
  // Assume form is already filled as part of precondition or prior test
  await page.click('button:has-text("Create Lead")');
  // Wait for success message
  const successMessage = await page.waitForSelector('text=Lead created successfully');
  await expect(successMessage).toBeVisible();
  // Capture Lead ID
  const leadIdElement = await page.waitForSelector('[data-test-id="lead-id"]');
  leadId = (await leadIdElement.textContent())?.trim() ?? '';
  expect(leadId).not.toBe('');
});

test('TC-008: Display newly created lead details', async ({ page }) => {
  // Ensure leadId is available from previous test
  expect(leadId).toBeTruthy();
  // Navigate to lead details page
  await page.goto(`/leads/${leadId}`);
  // Verify fields
  await expect(page.locator('[data-test-id="first-name"]').first()).toHaveText('John');
  await expect(page.locator('[data-test-id="last-name"]').first()).toHaveText('Doe');
  await expect(page.locator('[data-test-id="company-name"]').first()).toHaveText('Acme Corp');
  await expect(page.locator('[data-test-id="lead-id"]').first()).toHaveText(leadId);
});
