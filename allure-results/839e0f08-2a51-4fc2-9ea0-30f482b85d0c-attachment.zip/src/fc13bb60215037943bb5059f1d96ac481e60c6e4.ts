import { test, expect } from "@playwright/test";

test.describe("Transfer Validation", () => {
  test("TC-005: Validate transfer date entry is required", async ({ page }) => {
    await page.goto("/transfer");
    await page.selectOption('#sourceAccount', 'account1');
    await page.selectOption('#destinationAccount', 'account2');
    await page.fill('#amount', '75');
    await page.fill('#date', '');
    await page.click('#continue');
    const validationMessage = await page.locator('.validation-message').innerText();
    expect(validationMessage).toBe("Please select a transfer date");
    const confirmationScreen = await page.locator('#confirmationScreen');
    expect(await confirmationScreen.isVisible()).toBe(false);
  });

  test("TC-006: Reject transfer amounts below the minimum of $1.00", async ({ page }) => {
    await page.goto("/transfer");
    await page.selectOption('#sourceAccount', 'account1');
    await page.selectOption('#destinationAccount', 'account2');
    await page.fill('#amount', '0.50');
    await page.fill('#date', '2023-12-01');
    await page.click('#continue');
    const validationMessage = await page.locator('.validation-message').innerText();
    expect(validationMessage).toBe("Transfer amount must be at least $1.00");
    const confirmationScreen = await page.locator('#confirmationScreen');
    expect(await confirmationScreen.isVisible()).toBe(false);
  });
});