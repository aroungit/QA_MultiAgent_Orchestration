import { test, expect } from '@playwright/test';

test.describe('Fund Transfer', () => {
  test('TC-013: Update balance and transaction history after successful transfer', async ({ page }) => {
    // Assume user is already logged in and on the transfer page
    // Step: Complete the transfer
    await page.fill('#transfer-amount', '200');
    await page.selectOption('#beneficiary-select', { label: 'John Doe' });
    await page.click('text=Continue');

    // Re‑authentication (if prompted)
    if (await page.isVisible('#auth-password')) {
      await page.fill('#auth-password', 'password123');
      await page.click('text=Confirm');
    }

    // Wait for success notification
    await expect(page.locator('.notification-success')).toHaveText(/Transfer completed/);

    // Navigate to the source account summary page
    await page.click('nav >> text=Accounts');
    await page.click('text=Source Account'); // assumes account list

    // Check the displayed balance
    const balance = page.locator('.account-balance');
    await expect(balance).toHaveText('$800.00');

    // Open the transaction history for the source account
    await page.click('text=Transaction History');

    // Verify new transaction entry
    const transactionRow = page.locator('tr', { hasText: '$200.00' }).first();
    await expect(transactionRow).toContainText('John Doe');
    await expect(transactionRow).toContainText('Completed');
    // Assume reference ID is displayed in a cell with class .reference-id
    await expect(transactionRow.locator('.reference-id')).not.toBeEmpty();
  });

  test('TC-014: Ensure no funds are deducted when a transfer fails', async ({ page }) => {
    // Assume user is already logged in and on the transfer page
    // Step: Enter an amount of $600.00
    await page.fill('#transfer-amount', '600');
    await page.selectOption('#beneficiary-select', { label: 'Jane Smith' });
    await page.click('text=Continue');

    // Expect validation error
    const error = page.locator('.validation-error');
    await expect(error).toHaveText(/exceeds daily limit/);

    // Attempt to confirm transfer anyway (if button is still enabled)
    if (await page.isEnabled('text=Confirm')) {
      await page.click('text=Confirm');
    }

    // Observe the final outcome
    // Ensure transfer did not complete
    await expect(page.locator('.notification-success')).toHaveCount(0);
    await expect(page.locator('.notification-error')).toContainText(/Transfer could not be completed/);

    // Verify source account balance remains $500.00
    await page.click('nav >> text=Accounts');
    await page.click('text=Source Account');
    const balance = page.locator('.account-balance');
    await expect(balance).toHaveText('$500.00');

    // Verify no new entry in transaction history
    await page.click('text=Transaction History');
    const rows = page.locator('tr');
    // Assuming the latest transaction would have amount $600.00 if it existed
    await expect(rows.filter({ hasText: '$600.00' })).toHaveCount(0);
  });
});