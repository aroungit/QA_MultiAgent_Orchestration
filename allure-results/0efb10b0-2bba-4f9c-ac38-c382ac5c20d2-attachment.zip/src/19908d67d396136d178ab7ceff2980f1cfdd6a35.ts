import { test, expect } from '@playwright/test';

test.describe('Create Lead Page', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('https://leaftaps.com/opentaps/control/main');
    await page.fill('input[name="username"]', 'Democsr2');
    await page.fill('input[name="password"]', 'crmsfa');
    await page.click('button[type="submit"]');
    await page.click('text=Leads');
    await page.click('text=Create Lead');
  });

  test('TC-005: Enter Company Name', async ({ page }) => {
    const companyNameInput = page.locator('#company-name');
    await companyNameInput.fill('Valid Company Name');
    await expect(companyNameInput).toHaveValue('Valid Company Name');
  });

  test('TC-006: Click Create Lead Button', async ({ page }) => {
    await page.fill('#company-name', 'Valid Company Name');
    await page.click('#create-lead-button');
    const successMessage = page.locator('.success-message');
    await expect(successMessage).toBeVisible();
  });
});