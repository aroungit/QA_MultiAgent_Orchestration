import { test, expect } from '@playwright/test';

test('TC-005: Invalid credentials handling displays appropriate error message', async ({ page }) => {
  // Preconditions: user is on the login page
  await page.goto('/login');

  // Step 1: Enter invalid username
  await page.fill('input[name="username"]', 'invalidUser');

  // Step 2: Enter invalid password
  await page.fill('input[name="password"]', 'WrongPass');

  // Step 3: Click the enabled Login button
  await page.click('button:has-text("Login")');

  // Step 4: Observe the response area for messages
  const errorLocator = page.locator('div[data-test-id="login-error"]');
  await expect(errorLocator).toBeVisible();
  await expect(errorLocator).toContainText('Invalid username or password');

  // Expected result: user remains on the login page (no navigation)
  await expect(page).toHaveURL(/\/login$/);
});