import { test, expect } from '@playwright/test';

test.describe('Login Page', () => {
  test('TC-007: Non-empty Username and Password Fields', async ({ page }) => {
    // Navigate to the login page
    await page.goto('https://leaftaps.com/opentaps/control/main');

    // Leave the username field empty
    await page.fill('input[name="username"]', '');
    
    // Leave the password field empty
    await page.fill('input[name="password"]', '');
    
    // Click the Login button
    await page.click('button[type="submit"]');
    
    // Verify the error message
    const errorMessage = await page.locator('.error-message');
    await expect(errorMessage).toBeVisible();
    await expect(errorMessage).toHaveText(/fields cannot be empty/);
  });
});