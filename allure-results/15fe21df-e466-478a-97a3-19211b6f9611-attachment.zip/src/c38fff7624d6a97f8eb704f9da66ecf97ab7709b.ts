import { test, expect } from '@playwright/test';

test.describe('Transfer Validation', () => {
  test('TC-007: Reject transfer amounts exceeding available balance', async ({ page }) => {
    await page.goto('/transfer');
    await page.selectOption('#sourceAccount', 'checking');
    await page.selectOption('#destinationAccount', 'savings');
    await page.fill('#transferAmount', '250.00');
    await page.selectOption('#transferDate', 'future');
    await page.click('#continueButton');
    const validationMessage = await page.locator('#validationMessage').innerText();
    expect(validationMessage).toBe('Insufficient funds for this transfer');
    await expect(page).not.toHaveURL(/confirmation/);
  });

  test('TC-008: Reject past transfer dates', async ({ page }) => {
    await page.goto('/transfer');
    await page.selectOption('#sourceAccount', 'checking');
    await page.selectOption('#destinationAccount', 'savings');
    await page.fill('#transferAmount', '100');
    await page.selectOption('#transferDate', 'yesterday');
    await page.click('#continueButton');
    const validationMessage = await page.locator('#validationMessage').innerText();
    expect(validationMessage).toBe('Transfer date cannot be in the past');
    await expect(page).not.toHaveURL(/confirmation/);
  });
});