import { test, expect } from '@playwright/test';

test.describe('Lead Management', () => {
  test('TC-007: Lead Creation Success', async ({ page }) => {
    // Assuming the Create Lead button has a selector of '#create-lead'
    await page.click('#create-lead');
    // Wait for the success message to appear
    await page.waitForSelector('.success-message');
    const successMessage = await page.textContent('.success-message');
    expect(successMessage).toContain('Lead created successfully');
  });

  test('TC-008: Display Lead Information', async ({ page }) => {
    // Assuming the lead information is displayed in a section with the selector '#lead-info'
    const leadInfo = await page.textContent('#lead-info');
    expect(leadInfo).toContain('Newly created lead information');
  });
});