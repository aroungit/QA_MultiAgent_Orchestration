import { test, expect } from '@playwright/test';

test.describe('Transfers', () => {
  test.beforeEach(async ({ page }) => {
    // Assume user is already authenticated via storage state
    await page.goto('https://bank.example.com/dashboard');
  });

  test('TC-009: Account balance decrement and transaction history update after successful transfer', async ({ page }) => {
    // Navigate to transfer page
    await page.click('nav >> text=Transfer');
    // Select active beneficiary
    await page.selectOption('#beneficiary-select', { label: 'John Doe' });
    // Enter amount $200
    await page.fill('#transfer-amount', '200');
    // Submit transfer
    await page.click('#submit-transfer');
    // Wait for confirmation toast
    await expect(page.locator('.toast-success')).toContainText('Transfer completed');

    // Navigate to account summary
    await page.click('nav >> text=Account Summary');
    // Verify new balance $800
    const balanceText = await page.textContent('.balance-amount');
    expect(balanceText?.trim()).toBe('$800');

    // Navigate to transaction history
    await page.click('nav >> text=Transaction History');
    // Verify new transaction entry
    const transactionRow = page.locator('.transaction-row', { hasText: '$200' }).first();
    await expect(transactionRow).toContainText('John Doe');
    await expect(transactionRow).toContainText('Reference');
  });

  test('TC-010: No debit occurs when transfer fails', async ({ page }) => {
    // Navigate to transfer page
    await page.click('nav >> text=Transfer');
    // Select inactive beneficiary
    await page.selectOption('#beneficiary-select', { label: 'Jane Inactive' });
    // Enter amount $100
    await page.fill('#transfer-amount', '100');
    // Submit transfer
    await page.click('#submit-transfer');
    // Expect error message
    await expect(page.locator('#error-message')).toContainText('Beneficiary is not active');

    // Verify balance remains $500
    await page.click('nav >> text=Account Summary');
    const balanceText = await page.textContent('.balance-amount');
    expect(balanceText?.trim()).toBe('$500');

    // Verify no new transaction entry for $100
    await page.click('nav >> text=Transaction History');
    const failedTx = page.locator('.transaction-row', { hasText: '$100' });
    await expect(failedTx).toHaveCount(0);
  });
});