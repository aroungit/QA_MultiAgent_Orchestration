import { test, expect } from '@playwright/test';

test.describe('Create Lead page', () => {
  test.beforeEach(async ({ page }) => {
    // Navigate to the Create Lead page; adjust the base URL as needed
    await page.goto('https://example.com/leads/create');
  });

  test('TC-005: Enter lead company name', async ({ page }) => {
    const companyInput = page.locator('input[name="companyName"]');
    await expect(companyInput).toBeVisible();
    await companyInput.fill('Acme Corp');
    await expect(companyInput).toHaveValue('Acme Corp');
  });

  test('TC-006: Submit lead creation', async ({ page }) => {
    // Ensure required fields are populated (precondition)
    await page.locator('input[name="firstName"]').fill('John');
    await page.locator('input[name="lastName"]').fill('Doe');
    await page.locator('input[name="companyName"]').fill('Acme Corp');

    const createButton = page.locator('button:has-text("Create Lead")');
    await expect(createButton).toBeEnabled();
    await createButton.click();

    // Wait for loading indicator to disappear
    const loading = page.locator('.loading-spinner');
    await expect(loading).toBeHidden();

    // Verify navigation to confirmation or lead details view
    await expect(page).toHaveURL(/.*lead\/\d+/);
    await expect(page.locator('h1')).toContainText('Lead Details');
  });
});